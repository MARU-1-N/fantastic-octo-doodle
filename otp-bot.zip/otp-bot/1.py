from telethon import TelegramClient, events
from datetime import datetime
import re
import pytz
import traceback

# بيانات الدخول
api_id = 22762385
api_hash = "7b2bafa682c6852a5a9a8221ebfdadfc"

# قناة النشر للرسائل المفلترة
channel_output = "https://t.me/TeamElWeshaq"
# fallback: المستخدم الذي يستقبل الرسائل غير المفهومة أو عند حدوث خطأ
fallback_user = "@M_A_R_U_SSD"

# تعبير منتظم لاستخراج OTP (يشمل تنسيقات 123456 أو 123-456 أو 123 456)
otp_regex = re.compile(r"(?<!\d)(\d{3,4}[-\s]?\d{3,4})(?!\d)")

# استخراج رقم الهاتف (حتى لو فيه رموز مثل ⁕ أو • أو *)
number_regex = re.compile(r"(?:\+?\d{2,4}[⁕•*]*\d{2,4}[⁕•*]*\d{2,4}[⁕•*]*\d{2,4})")

# دوال التعرف على الدولة
def get_country_from_number(number):
    num = re.sub(r"[^\d]", "", number)  # إزالة كل الرموز ما عدا الأرقام
    if num.startswith("20") or num.startswith("01"):
        return "Egypt 🇪🇬"
    elif num.startswith("966"):
        return "Saudi Arabia 🇸🇦"
    elif num.startswith("91"):
        return "India 🇮🇳"
    elif num.startswith("255"):
        return "Tanzania 🇹🇿"
    elif num.startswith("1"):
        return "USA 🇺🇸"
    else:
        return None

# التنسيق النهائي للرسائل
def format_message(otp, time_str, country, number):
    return f"""📛 Team_El-Weshaq | اكواد التفعيل
━━━━━━━━━━━━━━━━━━━━━━━━
🔐 OTP: {otp}
🕒 Time: {time_str}
🌍 Country: {country if country else number}
☎️ Number: {number}
📢 قناة الأرقام: https://t.me/TeamElWeshaq1
━━━━━━━━━━━━━━━━━━━━━━━━"""

# بدء العميل
client = TelegramClient("otp_session", api_id, api_hash)

@client.on(events.NewMessage)
async def handler(event):
    try:
        text = event.raw_text

        otp_match = otp_regex.search(text)
        number_match = number_regex.search(text)

        # الوقت الحالي بتوقيت مصر
        now = datetime.now(pytz.timezone("Africa/Cairo"))
        time_str = now.strftime("%I:%M:%S %p")

        if otp_match and number_match:
            otp = otp_match.group(1)
            number = number_match.group(0)
            country = get_country_from_number(number)

            formatted = format_message(otp, time_str, country, number)
            await client.send_message(channel_output, formatted)
        else:
            await client.send_message(fallback_user, f"❌ لم يتم فلترة الرسالة:\n\n{text}")

    except Exception as e:
        error_msg = traceback.format_exc()
        await client.send_message(fallback_user, f"‼️ حصل خطأ في البوت:\n\n{error_msg}")

print("✅ Bot is running and listening for OTPs...")
client.start()
client.run_until_disconnected()
